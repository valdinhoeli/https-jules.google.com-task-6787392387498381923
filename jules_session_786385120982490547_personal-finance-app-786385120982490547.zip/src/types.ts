export type TransactionType = 'income' | 'expense';

export type Transaction = {
  id: string;
  description: string;
  amount: number;
  type: TransactionType;
  category: string;
  date: string;
};

export const DUMMY = true;
