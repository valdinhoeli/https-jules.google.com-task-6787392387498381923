import React from 'react';
import { TrendingUp, TrendingDown, Wallet } from 'lucide-react';
import type { Transaction } from '../types';

interface BalanceSummaryProps {
  transactions: Transaction[];
}

export const BalanceSummary: React.FC<BalanceSummaryProps> = ({ transactions }) => {
  const income = transactions
    .filter((t) => t.type === 'income')
    .reduce((acc, t) => acc + t.amount, 0);

  const expenses = transactions
    .filter((t) => t.type === 'expense')
    .reduce((acc, t) => acc + t.amount, 0);

  const balance = income - expenses;

  const formatCurrency = (value: number) => {
    return new Intl.NumberFormat('pt-BR', {
      style: 'currency',
      currency: 'BRL',
    }).format(value);
  };

  return (
    <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-8">
      <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-100">
        <div className="flex items-center justify-between mb-2">
          <span className="text-gray-500 text-sm font-medium">Receitas</span>
          <div className="bg-green-100 p-2 rounded-lg">
            <TrendingUp className="w-5 h-5 text-green-600" />
          </div>
        </div>
        <div className="text-2xl font-bold text-green-600">{formatCurrency(income)}</div>
      </div>

      <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-100">
        <div className="flex items-center justify-between mb-2">
          <span className="text-gray-500 text-sm font-medium">Despesas</span>
          <div className="bg-red-100 p-2 rounded-lg">
            <TrendingDown className="w-5 h-5 text-red-600" />
          </div>
        </div>
        <div className="text-2xl font-bold text-red-600">{formatCurrency(expenses)}</div>
      </div>

      <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-100">
        <div className="flex items-center justify-between mb-2">
          <span className="text-gray-500 text-sm font-medium">Saldo Total</span>
          <div className="bg-blue-100 p-2 rounded-lg">
            <Wallet className="w-5 h-5 text-blue-600" />
          </div>
        </div>
        <div className="text-2xl font-bold text-blue-600">{formatCurrency(balance)}</div>
      </div>
    </div>
  );
};
